FEM surface diffusion update: sfcmod 4, 5, and 6
=================================================

Changed files
-------------
- fespm.c: P1 triangular FEM diffusion now supports constant, power-law,
  and critical-slope diffusivity. Nonlinear element diffusivity is computed
  from the elementwise gradient of the current nodal surface field. The
  stiffness matrix is reassembled on every nonlinear diffusion step.
- fespm.h: API documentation updated for the three supported modes.
- geo_surf3mg.c: routes sfcmod=4,5,6 through FESPM diffusion, initializes
  FESPM for all three modes in both init_surface and reinit_surface, and
  checks the explicit FEM timestep limit in the surface loop.

Constitutive laws
-----------------
sfcmod = 4:
    kappa_e = k0

sfcmod = 5:
    kappa_e = k0 * |grad(h_h)|^d_exp

sfcmod = 6:
    kappa_e = k0 / (1 - (|grad(h_h)| / Sc)^d_exp)

For sfcmod=6, the denominator is regularized as in the original FDSPM
implementation: when |grad(h_h)|/Sc >= 1, the nonlinear term is capped at
1 - 1e-5, so kappa does not diverge. Sc is set as tan(sfc_diff_threshold
in degrees), matching the existing surface setup.

FEM details
-----------
- The existing structured quadrilateral surface grid is split into P1
  triangles.
- P1 gradients are constant within each triangle; therefore one kappa value
  is evaluated per triangle.
- The local diffusion matrix is integrated with that elementwise kappa and
  assembled into the global stiffness matrix.
- For sfcmod 5 and 6, the mass matrix is reused, while the stiffness matrix
  is rebuilt from the current surface field before each diffusion solve.
- The second-order MUSCL FVM advection step is used for all surface modes; FEM handles
  the diffusion/uplift stage.

Validation performed
--------------------
- `fespm.c` passed GCC C99 syntax checking with `-Wall -Wextra`.
- `geo_surf3mg.c` passed GCC syntax checking; GCC emitted one existing warning
  about the external LAPACK routine `dgesv_` in `planeq()` (unrelated to these
  FEM changes).

