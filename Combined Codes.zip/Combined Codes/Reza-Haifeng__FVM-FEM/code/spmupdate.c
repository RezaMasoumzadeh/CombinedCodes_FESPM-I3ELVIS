#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "spm.h"
#include "fespm.h"

ErrorCode FEFVSPMComputeTimestep_CFL(FEFVSPM s, double uh[], double *dt);

/* ================================================================
 * Diffusivity constitutive laws (unchanged from original)
 * ================================================================ */

ErrorCode FEFVSPMComputeDiffusivity_Constant(FEFVSPM s, double h[])
{
  ErrorCode ierr;
  CentroidIteratorBegin(s)
      s->kappa[CellIdx(s, mi, mj)] = s->k0;
  CentroidIteratorEnd(s)
  return (0);
}

ErrorCode FEFVSPMComputeDiffusivity_Constant_SACoeff(FEFVSPM s, double h[])
{
  ErrorCode ierr;
  CentroidIteratorBegin(s)
  {
    double avg = 0.0;
    avg += s->k0_n[NodeIdx(s, mi, mj)];
    avg += s->k0_n[NodeIdx(s, mi + 1, mj)];
    avg += s->k0_n[NodeIdx(s, mi, mj + 1)];
    avg += s->k0_n[NodeIdx(s, mi + 1, mj + 1)];
    s->kappa[CellIdx(s, mi, mj)] = 0.25 * avg;
  }
  CentroidIteratorEnd(s)
  return (0);
}

ErrorCode FEFVSPMComputeDiffusivity_NonlinearCriticalSlope(FEFVSPM s, double h[])
{
  ErrorCode ierr;
  double kstar, gradh[2], norm, avghx[2], avghy[2], nls;
  int ni, nj, nid, cid_ij;

  CentroidIteratorBegin(s)
      cid_ij = CellIdx(s, mi, mj);

  ni = mi;
  nj = mj;

  avghx[1] = 0.5 * (h[NodeIdx(s, ni + 1, nj)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghx[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni, nj + 1)]);

  avghy[1] = 0.5 * (h[NodeIdx(s, ni, nj + 1)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghy[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni + 1, nj)]);

  gradh[0] = (avghx[1] - avghx[0]) / s->dx;
  gradh[1] = (avghy[1] - avghy[0]) / s->dy;

  norm = sqrt(gradh[0] * gradh[0] + gradh[1] * gradh[1]);

  nls = pow(norm / s->Sc, s->d_exp);
  if (nls > 1.0) nls = 1.0 - 0.00001;

  kstar = s->k0 / (1.0 - nls);

  if (kstar < 0.0)
  {
    printf("gradh[0] = %1.6e\n", gradh[0]);
    printf("gradh[1] = %1.6e\n", gradh[1]);
    printf("norm = %1.6e\n", norm);
    printf("norm/Sc = %1.6e\n", norm / s->Sc);
    printf("pow(norm/s->Sc,s->d_exp) = %1.6e\n", pow(norm / s->Sc, s->d_exp));
    printf("nls = %1.6e \n", nls);
    printf("1.0 - pow(norm/s->Sc,s->d_exp) = %1.6e\n", 1.0 - pow(norm / s->Sc, s->d_exp));
  }

  s->kappa[cid_ij] = kstar;
  CentroidIteratorEnd(s)
  return (0);
}

ErrorCode FEFVSPMComputeDiffusivity_NonlinearCriticalSlope_SACoeff(FEFVSPM s, double h[])
{
  ErrorCode ierr;
  double kstar, gradh[2], norm, avghx[2], avghy[2], nls, Sc, d_exp, k0;
  int ni, nj, nid, cid_ij;

  CentroidIteratorBegin(s)
      cid_ij = CellIdx(s, mi, mj);

  ni = mi;
  nj = mj;

  avghx[1] = 0.5 * (h[NodeIdx(s, ni + 1, nj)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghx[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni, nj + 1)]);

  avghy[1] = 0.5 * (h[NodeIdx(s, ni, nj + 1)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghy[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni + 1, nj)]);

  gradh[0] = (avghx[1] - avghx[0]) / s->dx;
  gradh[1] = (avghy[1] - avghy[0]) / s->dy;

  norm = sqrt(gradh[0] * gradh[0] + gradh[1] * gradh[1]);

  {
    double avg[] = {0.0, 0.0, 0.0};

    avg[0] += s->k0_n[NodeIdx(s, mi, mj)];
    avg[0] += s->k0_n[NodeIdx(s, mi + 1, mj)];
    avg[0] += s->k0_n[NodeIdx(s, mi, mj + 1)];
    avg[0] += s->k0_n[NodeIdx(s, mi + 1, mj + 1)];

    avg[1] += s->d_exp_n[NodeIdx(s, mi, mj)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi + 1, mj)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi, mj + 1)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi + 1, mj + 1)];

    avg[2] += s->Sc_n[NodeIdx(s, mi, mj)];
    avg[2] += s->Sc_n[NodeIdx(s, mi + 1, mj)];
    avg[2] += s->Sc_n[NodeIdx(s, mi, mj + 1)];
    avg[2] += s->Sc_n[NodeIdx(s, mi + 1, mj + 1)];

    k0 = 0.25 * avg[0];
    d_exp = 0.25 * avg[1];
    Sc = 0.25 * avg[2];
  }

  nls = pow(norm / Sc, d_exp);
  if (nls > 1.0) nls = 1.0 - 0.00001;

  kstar = k0 / (1.0 - nls);

  if (kstar < 0.0)
  {
    printf("gradh[0] = %1.6e\n", gradh[0]);
    printf("gradh[1] = %1.6e\n", gradh[1]);
    printf("norm = %1.6e\n", norm);
    printf("norm/Sc = %1.6e\n", norm / Sc);
    printf("pow(norm/Sc,d_exp) = %1.6e\n", pow(norm / Sc, d_exp));
    printf("nls = %1.6e \n", nls);
    printf("1.0 - pow(norm/Sc,d_exp) = %1.6e\n", 1.0 - pow(norm / Sc, d_exp));
  }

  s->kappa[cid_ij] = kstar;
  CentroidIteratorEnd(s)
  return (0);
}

ErrorCode FEFVSPMComputeDiffusivity_NonlinearPowerLaw(FEFVSPM s, double h[])
{
  ErrorCode ierr;
  double kstar, gradh[2], norm, avghx[2], avghy[2];
  int ni, nj, nid, cid_ij;

  CentroidIteratorBegin(s)
      cid_ij = CellIdx(s, mi, mj);

  ni = mi;
  nj = mj;

  avghx[1] = 0.5 * (h[NodeIdx(s, ni + 1, nj)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghx[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni, nj + 1)]);

  avghy[1] = 0.5 * (h[NodeIdx(s, ni, nj + 1)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghy[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni + 1, nj)]);

  gradh[0] = (avghx[1] - avghx[0]) / s->dx;
  gradh[1] = (avghy[1] - avghy[0]) / s->dy;

  norm = sqrt(gradh[0] * gradh[0] + gradh[1] * gradh[1]);
  kstar = s->k0 * pow(norm, s->d_exp);
  s->kappa[cid_ij] = kstar;
  CentroidIteratorEnd(s)
  return (0);
}

ErrorCode FEFVSPMComputeDiffusivity_NonlinearPowerLaw_SACoeff(FEFVSPM s, double h[])
{
  ErrorCode ierr;
  double kstar, gradh[2], norm, avghx[2], avghy[2], k0, d_exp;
  int ni, nj, nid, cid_ij;

  CentroidIteratorBegin(s)
      cid_ij = CellIdx(s, mi, mj);

  ni = mi;
  nj = mj;

  avghx[1] = 0.5 * (h[NodeIdx(s, ni + 1, nj)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghx[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni, nj + 1)]);

  avghy[1] = 0.5 * (h[NodeIdx(s, ni, nj + 1)] + h[NodeIdx(s, ni + 1, nj + 1)]);
  avghy[0] = 0.5 * (h[NodeIdx(s, ni, nj)] + h[NodeIdx(s, ni + 1, nj)]);

  gradh[0] = (avghx[1] - avghx[0]) / s->dx;
  gradh[1] = (avghy[1] - avghy[0]) / s->dy;

  norm = sqrt(gradh[0] * gradh[0] + gradh[1] * gradh[1]);

  {
    double avg[] = {0.0, 0.0};

    avg[0] += s->k0_n[NodeIdx(s, mi, mj)];
    avg[0] += s->k0_n[NodeIdx(s, mi + 1, mj)];
    avg[0] += s->k0_n[NodeIdx(s, mi, mj + 1)];
    avg[0] += s->k0_n[NodeIdx(s, mi + 1, mj + 1)];

    avg[1] += s->d_exp_n[NodeIdx(s, mi, mj)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi + 1, mj)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi, mj + 1)];
    avg[1] += s->d_exp_n[NodeIdx(s, mi + 1, mj + 1)];

    k0 = 0.25 * avg[0];
    d_exp = 0.25 * avg[1];
  }

  kstar = k0 * pow(norm, d_exp);
  s->kappa[cid_ij] = kstar;
  CentroidIteratorEnd(s)
  return (0);
}

ErrorCode FEFVSPMComputeDiffusivity(FEFVSPM s, double h[])
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FEFVSPMComputeDiffusivity_Constant(s, h);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FEFVSPMComputeDiffusivity_NonlinearCriticalSlope(s, h);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FEFVSPMComputeDiffusivity_NonlinearPowerLaw(s, h);
    break;
  case DM_UNDEFINED:
    break;
  }

  {
    int cid_ij;
    CentroidIteratorBegin(s)
        cid_ij = CellIdx(s, mi, mj);
    if (s->kappa[cid_ij] < 0.0) ERRQ("kappa < 0");
    CentroidIteratorEnd(s)
  }
  return (0);
}

ErrorCode FEFVSPMComputeDiffusivity_SpatialAveragedCoefficients(FEFVSPM s, double h[])
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FEFVSPMComputeDiffusivity_Constant_SACoeff(s, h);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FEFVSPMComputeDiffusivity_NonlinearCriticalSlope_SACoeff(s, h);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FEFVSPMComputeDiffusivity_NonlinearPowerLaw_SACoeff(s, h);
    break;
  case DM_UNDEFINED:
    break;
  }

  {
    int cid_ij;
    CentroidIteratorBegin(s)
        cid_ij = CellIdx(s, mi, mj);
    if (s->kappa[cid_ij] < 0.0) ERRQ("kappa < 0");
    CentroidIteratorEnd(s)
  }
  return (0);
}

/* ================================================================
 * Timestep
 * ================================================================ */

ErrorCode FEFVSPMComputeTimestep_explicit(FEFVSPM s, double h[], double *dt)
{
  ErrorCode ierr;
  double dt_min, ds, sx, sy, fac, kappa, _dt;
  int cidx;

  sx = 1.0 / (s->dx * s->dx);
  sy = 1.0 / (s->dy * s->dy);
  fac = 0.5 / (sx + sy);
  dt_min = 1.0e32;
  CentroidIteratorBegin(s)
      cidx = CellIdx(s, mi, mj);
  kappa = s->kappa[cidx];
  _dt = fac / kappa;
  if (_dt < dt_min) dt_min = _dt;
  CentroidIteratorEnd(s)
  *dt = dt_min * s->dt_theta;
  return (0);
}

ErrorCode FEFVSPMComputeTimestep_const(FEFVSPM s, double *dt)
{
  ErrorCode ierr;
  *dt = s->dt_const;
  return (0);
}

ErrorCode FEFVSPMComputeTimestep(FEFVSPM s, double h[], double *dt)
{
  ErrorCode ierr;

  switch (s->dtmode)
  {
  case DTM_CONST:
    ierr = FEFVSPMComputeTimestep_const(s, dt);
    break;
  case DTM_EXPLICIT:
  {
    double dt_d, dt_a;
    ierr = FEFVSPMComputeTimestep_explicit(s, h, &dt_d);
    ierr = FEFVSPMComputeTimestep_CFL(s, s->u_h, &dt_a);
    if (dt_d < dt_a) *dt = dt_d; else *dt = dt_a;
  }
  break;
  }
  if (*dt < 0.0) ERRQ("Timestep is negative");
  if (isnan(*dt)) ERRQ("Timestep is NaN");
  if (isinf(*dt)) ERRQ("Timestep is Inf");
  if (*dt < s->dt_min) *dt = s->dt_min;
  if (*dt > s->dt_max) *dt = s->dt_max;
  if (*dt > s->time_end) ERRQ("Timestep is larger than final time");
  return (0);
}

/* ================================================================
 * Diffusion update kernels (FD path — used only for sfcmod < 4)
 * ================================================================ */

ErrorCode FEFVSPMUpdate_VariableDiffusivity(FEFVSPM s, double hc[])
{
  ErrorCode ierr;
  double qx[2], qy[2];
  double kx[2], ky[2], div_q;
  int nidx_ij;

  NodalIteratorInteriorBegin(s)
      nidx_ij = NodeIdx(s, ni, nj);

  kx[1] = 0.5 * (s->kappa[CellIdx(s, ni, nj)] + s->kappa[CellIdx(s, ni, nj - 1)]);
  kx[0] = 0.5 * (s->kappa[CellIdx(s, ni - 1, nj)] + s->kappa[CellIdx(s, ni - 1, nj - 1)]);

  ky[1] = 0.5 * (s->kappa[CellIdx(s, ni, nj)] + s->kappa[CellIdx(s, ni - 1, nj)]);
  ky[0] = 0.5 * (s->kappa[CellIdx(s, ni, nj - 1)] + s->kappa[CellIdx(s, ni - 1, nj - 1)]);

  qx[1] = -kx[1] * (hc[NodeIdx(s, ni + 1, nj)] - hc[NodeIdx(s, ni, nj)]) / s->dx;
  qx[0] = -kx[0] * (hc[NodeIdx(s, ni, nj)] - hc[NodeIdx(s, ni - 1, nj)]) / s->dx;

  qy[1] = -ky[1] * (hc[NodeIdx(s, ni, nj + 1)] - hc[NodeIdx(s, ni, nj)]) / s->dy;
  qy[0] = -ky[0] * (hc[NodeIdx(s, ni, nj)] - hc[NodeIdx(s, ni, nj - 1)]) / s->dy;

  div_q = (qx[1] - qx[0]) / s->dx + (qy[1] - qy[0]) / s->dy;
  s->h[nidx_ij] = hc[nidx_ij] + s->dt * s->u_v[nidx_ij] - s->dt * div_q;
  NodalIteratorInteriorEnd(s)
  return (0);
}

ErrorCode FEFVSPMUpdate_ConstantDiffusion(FEFVSPM s, double hc[])
{
  ErrorCode ierr;
  double nabla2T, idx2, idy2, div_q;
  int nidx_ij;

  NodalIteratorInteriorBegin(s)
      nidx_ij = NodeIdx(s, ni, nj);

  idx2 = 1.0 / (s->dx * s->dx);
  idy2 = 1.0 / (s->dy * s->dy);

  nabla2T = idx2 * (hc[NodeIdx(s, ni + 1, nj)] - 2.0 * hc[nidx_ij] + hc[NodeIdx(s, ni - 1, nj)]);
  nabla2T += idy2 * (hc[NodeIdx(s, ni, nj + 1)] - 2.0 * hc[nidx_ij] + hc[NodeIdx(s, ni, nj - 1)]);

  div_q = s->k0 * nabla2T;
  s->h[nidx_ij] = hc[nidx_ij] + s->dt * s->u_v[nidx_ij] + s->dt * div_q;
  NodalIteratorInteriorEnd(s)
  return (0);
}

ErrorCode FEFVSPMUpdate_ConstantAveragedDiffusion(FEFVSPM s, double hc[])
{
  ErrorCode ierr;
  double nabla2T, idx2, idy2, div_q, avg_kappa;
  int nidx_ij;

  NodalIteratorInteriorBegin(s)
      nidx_ij = NodeIdx(s, ni, nj);

  idx2 = 1.0 / (s->dx * s->dx);
  idy2 = 1.0 / (s->dy * s->dy);

  nabla2T = idx2 * (hc[NodeIdx(s, ni + 1, nj)] - 2.0 * hc[nidx_ij] + hc[NodeIdx(s, ni - 1, nj)]);
  nabla2T += idy2 * (hc[NodeIdx(s, ni, nj + 1)] - 2.0 * hc[nidx_ij] + hc[NodeIdx(s, ni, nj - 1)]);

  avg_kappa = s->kappa[CellIdx(s, ni - 1, nj - 1)];
  avg_kappa += s->kappa[CellIdx(s, ni, nj - 1)];
  avg_kappa += s->kappa[CellIdx(s, ni - 1, nj)];
  avg_kappa += s->kappa[CellIdx(s, ni, nj)];
  avg_kappa = 0.25 * avg_kappa;

  div_q = avg_kappa * nabla2T;
  s->h[nidx_ij] = hc[nidx_ij] + s->dt * s->u_v[nidx_ij] + s->dt * div_q;
  NodalIteratorInteriorEnd(s)
  return (0);
}

ErrorCode FEFVSPMUpdate_EnforceBoundaryConditions(FEFVSPM s, double field[])
{
  int ni, nj, nidx_ij, nidx_neighbour;

  if (s->bctype[DIR_JMAX] == 'N')
  {
    nj = s->ny - 1;
    for (ni = 1; ni < s->nx - 1; ni++)
    {
      nidx_ij = NodeIdx(s, ni, nj);
      nidx_neighbour = NodeIdx(s, ni, nj - 1);
      field[nidx_ij] = field[nidx_neighbour];
    }
  }
  if (s->bctype[DIR_JMIN] == 'N')
  {
    nj = 0;
    for (ni = 1; ni < s->nx - 1; ni++)
    {
      nidx_ij = NodeIdx(s, ni, nj);
      nidx_neighbour = NodeIdx(s, ni, nj + 1);
      field[nidx_ij] = field[nidx_neighbour];
    }
  }
  if (s->bctype[DIR_IMAX] == 'N')
  {
    ni = s->nx - 1;
    for (nj = 1; nj < s->ny - 1; nj++)
    {
      nidx_ij = NodeIdx(s, ni, nj);
      nidx_neighbour = NodeIdx(s, ni - 1, nj);
      field[nidx_ij] = field[nidx_neighbour];
    }
  }
  if (s->bctype[DIR_IMIN] == 'N')
  {
    ni = 0;
    for (nj = 1; nj < s->ny - 1; nj++)
    {
      nidx_ij = NodeIdx(s, ni, nj);
      nidx_neighbour = NodeIdx(s, ni + 1, nj);
      field[nidx_ij] = field[nidx_neighbour];
    }
  }

  if ((s->bctype[DIR_JMAX] == 'N') && (s->bctype[DIR_IMAX] == 'N'))
  {
    ni = s->nx - 1; nj = s->ny - 1;
    nidx_ij = NodeIdx(s, ni, nj);
    nidx_neighbour = NodeIdx(s, ni - 1, nj - 1);
    field[nidx_ij] = field[nidx_neighbour];
  }
  if ((s->bctype[DIR_JMIN] == 'N') && (s->bctype[DIR_IMAX] == 'N'))
  {
    ni = s->nx - 1; nj = 0;
    nidx_ij = NodeIdx(s, ni, nj);
    nidx_neighbour = NodeIdx(s, ni - 1, nj + 1);
    field[nidx_ij] = field[nidx_neighbour];
  }
  if ((s->bctype[DIR_JMIN] == 'N') && (s->bctype[DIR_IMIN] == 'N'))
  {
    ni = 0; nj = 0;
    nidx_ij = NodeIdx(s, ni, nj);
    nidx_neighbour = NodeIdx(s, ni + 1, nj + 1);
    field[nidx_ij] = field[nidx_neighbour];
  }
  if ((s->bctype[DIR_IMIN] == 'N') && (s->bctype[DIR_JMAX] == 'N'))
  {
    ni = 0; nj = s->ny - 1;
    nidx_ij = NodeIdx(s, ni, nj);
    nidx_neighbour = NodeIdx(s, ni + 1, nj - 1);
    field[nidx_ij] = field[nidx_neighbour];
  }
  return (0);
}

ErrorCode FEFVSPMUpdate_Diffusion(FEFVSPM s, double hc[])
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FEFVSPMUpdate_ConstantDiffusion(s, hc);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FEFVSPMUpdate_VariableDiffusivity(s, hc);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FEFVSPMUpdate_ConstantAveragedDiffusion(s, hc);
    break;
  case DM_UNDEFINED:
    ERRQ("Undefined diffusivity mode detected");
    break;
  default:
    ERRQ("Unknown diffusivity mode detected");
    break;
  }

  ierr = FEFVSPMUpdate_EnforceBoundaryConditions(s, s->h);
  return (0);
}

ErrorCode FEFVSPMUpdate_Diffusion_SpatialAveragedCoefficients(FEFVSPM s, double hc[])
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FEFVSPMUpdate_VariableDiffusivity(s, hc);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FEFVSPMUpdate_VariableDiffusivity(s, hc);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FEFVSPMUpdate_ConstantAveragedDiffusion(s, hc);
    break;
  case DM_UNDEFINED:
    ERRQ("Undefined diffusivity mode detected");
    break;
  default:
    ERRQ("Unknown diffusivity mode detected");
    break;
  }
  ierr = FEFVSPMUpdate_EnforceBoundaryConditions(s, s->h);
  return (0);
}

ErrorCode FEFVSPMView(FEFVSPM s)
{
  printf("FEFVSPM:\n");
  printf("  domain [%1.4e,%1.4e] x [%1.4e,%1.4e] \n", s->xrange[0], s->xrange[1], s->yrange[0], s->yrange[1]);
  printf("  nx %4d\n", s->nx);
  printf("  ny %4d\n", s->ny);
  printf("  time_end %1.4e\n", s->time_end);
  printf("  maxsteps %d\n", s->nt_max);
  printf("  output every %d\n", s->nt_io);

  printf("  timestep mode %d\n", (int)s->dtmode);
  switch (s->dtmode)
  {
  case DTM_CONST:
    printf("    dt_const %1.4e\n", s->dt_const);
    break;
  case DTM_EXPLICIT:
    printf("    dt_theta %1.4e\n", s->dt_theta);
    printf("    dt(%D) %1.4e\n", s->nt, s->dt);
    break;
  }

  printf("  diffusion mode %d\n", (int)s->mode);
  switch (s->mode)
  {
  case DM_CONST:
    printf("    k0 %1.4e\n", s->k0);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    printf("    k0 %1.4e , m %1.4e Sc %1.4e\n", s->k0, s->d_exp, s->Sc);
    break;
  case DM_NONLINEAR_POWERLAW:
    printf("    k0 %1.4e , m %1.4e\n", s->k0, s->d_exp);
    break;
  case DM_UNDEFINED:
    break;
  }
  return (0);
}

ErrorCode FEFVSPMStepInitialize(FEFVSPM s)
{
  ErrorCode ierr;

  s->time = 0.0;
  s->nt = 0;

  ierr = FEFVSPMUpdate_EnforceBoundaryConditions(s, s->h_ic);
  memcpy(s->h, s->h_ic, sizeof(double) * s->nnodes);
  memcpy(s->h_c, s->h_ic, sizeof(double) * s->nnodes);

  ierr = FEFVSPMCheckpoint(s);
  return (0);
}

ErrorCode FEFVSPMStepDiff(FEFVSPM s)
{
  ErrorCode ierr;
  int tk;

  printf("____ FEFVSPM Diff integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FEFVSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {
    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);
    ierr = FEFVSPMComputeDiffusivity(s, s->h_c);
    ierr = FEFVSPMComputeTimestep(s, s->h_c, &s->dt);

    if (s->time + s->dt > s->time_end) s->dt = s->time_end - s->time;

    ierr = FEFVSPMUpdate_Diffusion(s, s->h_c);

    s->time += s->dt;
    s->nt++;
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);

    if (s->nt % s->nt_io == 0)
    {
      ierr = FEFVSPMFieldView(s, FVT_VTRB);
      ierr = FEFVSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  FEFVSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == (s->nt_max)) printf("  FEFVSPM: Reached max number of time steps permitted\n");
  return (0);
}

ErrorCode FEFVSPMStepDiff_TimeDependentInput(FEFVSPM s, ErrorCode (*user_update_function)(FEFVSPM, double, int, double, void *), void *ctx)
{
  ErrorCode ierr;
  int tk;

  printf("____ FEFVSPM Diff + TimeDependentInput integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FEFVSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {
    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);

    if (user_update_function) ierr = user_update_function(s, s->time, s->nt, s->dt, ctx);

    ierr = FEFVSPMComputeDiffusivity(s, s->h_c);
    ierr = FEFVSPMComputeTimestep(s, s->h_c, &s->dt);

    if (s->time + s->dt > s->time_end) s->dt = s->time_end - s->time;

    ierr = FEFVSPMUpdate_Diffusion(s, s->h_c);

    s->time += s->dt;
    s->nt++;
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);

    if (s->nt % s->nt_io == 0)
    {
      ierr = FEFVSPMFieldView(s, FVT_VTRB);
      ierr = FEFVSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  FEFVSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == (s->nt_max)) printf("  FEFVSPM: Reached max number of time steps permitted\n");
  return (0);
}

/* ================================================================
 * AdvDiff integrator  —  MODIFIED: uses FVM advection
 * ================================================================ */
ErrorCode FEFVSPMStepAdvDiff(FEFVSPM s)
{
  ErrorCode ierr;
  int tk;

  printf("____ FEFVSPM AdvDiff integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FEFVSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {
    ierr = FEFVSPMComputeTimestep(s, s->h, &s->dt);
    if (ierr != 0) {
      printf("FATAL: FEFVSPMComputeTimestep failed\n");
      return ierr;
    }

    /* Enforce MUSCL FVM advection CFL */
    {
      double dt_adv_stable;
      ierr = FEFVSPMGetStableTimestep_FVMAdvection(s, 0.8, &dt_adv_stable);
      if (ierr != 0) {
        printf("FATAL: FEFVSPMGetStableTimestep_FVMAdvection failed\n");
        return ierr;
      }
      if (dt_adv_stable > 0.0 && s->dt > dt_adv_stable) {
        s->dt = dt_adv_stable;
      }
    }

    if (s->time + s->dt > s->time_end) s->dt = s->time_end - s->time;

    /* Second-order MUSCL FVM advection */
    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->h);
    if (ierr != 0) {
      printf("FATAL: FEFVSPMUpdate_FVMAdvection_2ndOrder failed\n");
      return ierr;
    }

    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);

    ierr = FESPMDiffusionStep(s->fespm, s, s->h_c);
    if (ierr != 0) {
      printf("FATAL: FESPMDiffusionStep failed\n");
      return ierr;
    }

    s->time += s->dt;
    s->nt++;
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);

    if (s->nt % s->nt_io == 0)
    {
      ierr = FEFVSPMFieldView(s, FVT_VTRB);
      ierr = FEFVSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  FEFVSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == (s->nt_max)) printf("  FEFVSPM: Reached max number of time steps permitted\n");
  return (0);
}

ErrorCode FEFVSPMStepAdvDiff_TimeDependentInput(FEFVSPM s, ErrorCode (*user_update_function)(FEFVSPM, double, int, double, void *), void *ctx)
{
  ErrorCode ierr;
  int tk;

  printf("____ FEFVSPM AdvDiff + TimeDependentInput integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FEFVSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {
    if (user_update_function) ierr = user_update_function(s, s->time, s->nt, s->dt, ctx);

    ierr = FEFVSPMComputeDiffusivity(s, s->h);
    ierr = FEFVSPMComputeTimestep(s, s->h, &s->dt);

    if (s->time + s->dt > s->time_end) s->dt = s->time_end - s->time;

    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->h);

    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);
    ierr = FEFVSPMUpdate_Diffusion(s, s->h_c);

    s->time += s->dt;
    s->nt++;
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);

    if (s->nt % s->nt_io == 0)
    {
      ierr = FEFVSPMFieldView(s, FVT_VTRB);
      ierr = FEFVSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  FEFVSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == (s->nt_max)) printf("  FEFVSPM: Reached max number of time steps permitted\n");
  return (0);
}

ErrorCode FEFVSPMUpdate_TimeDepCoefficients(FEFVSPM s)
{
  ErrorCode ierr;

  switch (s->mode)
  {
  case DM_CONST:
    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->k0_n);
    break;
  case DM_NONLINEAR_CRITICALSLOPE:
    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->k0_n);
    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->d_exp_n);
    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->Sc_n);
    break;
  case DM_NONLINEAR_POWERLAW:
    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->k0_n);
    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->d_exp_n);
    break;
  case DM_UNDEFINED:
    ERRQ("Undefined diffusivity mode detected");
    break;
  default:
    ERRQ("Unknown diffusivity mode detected");
    break;
  }
  return (0);
}

ErrorCode FEFVSPMStepAdvDiff_TimeDepCoefficients(FEFVSPM s)
{
  ErrorCode ierr;
  int tk;

  printf("____ FEFVSPM AdvDiff + CoeffEvolution integrator ____\n");
  printf("  current time/step %1.4e/%d : target time %1.4e : max steps %d\n", s->time, s->nt, s->time_end, s->nt_max);

  if (s->time >= s->time_end)
  {
    printf("  FEFVSPM: No updates performed as already at target end time\n");
    return (0);
  }

  for (tk = 0; tk < s->nt_max; tk++)
  {
    ierr = FEFVSPMComputeDiffusivity_SpatialAveragedCoefficients(s, s->h);
    ierr = FEFVSPMComputeTimestep(s, s->h, &s->dt);

    if (s->time + s->dt > s->time_end) s->dt = s->time_end - s->time;

    ierr = FEFVSPMUpdate_FVMAdvection_2ndOrder(s, s->dt, s->h);
    ierr = FEFVSPMUpdate_TimeDepCoefficients(s);

    memcpy(s->h_c, s->h, sizeof(double) * s->nnodes);
    ierr = FEFVSPMUpdate_Diffusion_SpatialAveragedCoefficients(s, s->h_c);

    s->time += s->dt;
    s->nt++;

    if ((tk + 1) % 50 == 0)
    {
      printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);
    }

    if (s->nt % s->nt_io == 0)
    {
      ierr = FEFVSPMFieldView(s, FVT_VTRB);
      ierr = FEFVSPMCheckpoint(s);
    }
    if (s->time >= s->time_end)
    {
      printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);
      printf("  FEFVSPM: Reached target end time\n");
      break;
    }
  }
  if (tk == s->nt_max)
  {
    printf("  step %4d: time %1.4e, dt %1.4e\n", s->nt, s->time, s->dt);
    printf("  FEFVSPM: Reached max number of time steps permitted\n");
  }
  return (0);
}