#include <stdio.h>
#include <math.h>
#include "spm.h"

ErrorCode FEFVSPMComputeTimestep_CFL(FEFVSPM s,double uh[],double *dt)
{
  ErrorCode ierr;
  double sx,sy,ds,dt_min,vmax,vx,vy,vs;
  int nidx_ij;
  double CFL_max = 2.0;

  ds = s->dx;
  if (s->dy < ds) {
    ds = s->dy;
  }

  dt_min = 1.0e32;

  vmax = 0.0;
  NodalIteratorBegin(s)
  nidx_ij = NodeIdx(s,ni,nj);
  vx = uh[2*nidx_ij+0];
  vy = uh[2*nidx_ij+1];
  vs = vx*vx + vy*vy;
  if (vs > vmax) { vmax = vs; }
  NodalIteratorEnd(s)

  if (vmax < 1.0e-20) {
    *dt = 1.0e32;
  } else {
    *dt = CFL_max * (ds / sqrt(vmax));
  }

  return(0);
}

/* ============================================================
 * ============================================================
 * SECOND-ORDER MUSCL FINITE-VOLUME ADVECTION
 * ============================================================
 *
 * Solves the conservative advection equation
 *
 *     dh/dt + div( u_h * h ) = 0
 *
 * on the same structured vertex-centered grid using a
 * MUSCL-Hancock (predictor-corrector) scheme with MC limiter.
 *
 * - Spatial order  : 2 (MC-limited linear reconstruction)
 * - Temporal order : 2 (Hancock half-step predictor)
 * - TVD            : yes (MC limiter)
 *
 * Vertex-centered median-dual control volumes:
 *   - interior nodes : dx*dy,       face lengths dx, dy
 *   - edge   nodes   : dx*dy / 2,   face lengths dx/2 or dy/2
 *   - corner nodes   : dx*dy / 4,   face lengths dx/2 and dy/2
 *
 * Boundary face fluxes:
 *   The median-dual face on a domain boundary is located AT the
 *   boundary node.  The reconstructed face value is therefore the
 *   predicted nodal value h*, with NO slope correction.  This is
 *   consistent with zero-order extrapolation as the boundary
 *   condition:
 *     - u_n = 0        -> pure wall (zero flux)
 *     - u_n pointing out -> outflow with h_f = h*_boundary
 *     - u_n pointing in  -> inflow  with h_f = h*_boundary
 *
 * Assumes: u_h is constant in space and time.
 *          (div u_H = 0 -> conservative = non-conservative form)
 * ============================================================ */

static double fvm_mc_limiter(double dl, double dr)
{
    double s, m;
    if (dl * dr <= 0.0) return 0.0;
    s = 0.5 * (dl + dr);
    m = fabs(dl);
    if (fabs(dr) < m) m = fabs(dr);
    m *= 2.0;
    if (fabs(s) < m) m = fabs(s);
    return (s > 0.0) ? m : -m;
}

ErrorCode FEFVSPMUpdate_FVMAdvection_2ndOrder(FEFVSPM s, double dt, double hc[])
{
    int nx = s->nx, ny = s->ny;
    double dx = s->dx, dy = s->dy;
    int nnodes = s->nnodes;
    int i, j, idx;

    double *slope_x = (double *)malloc(nnodes * sizeof(double));
    double *slope_y = (double *)malloc(nnodes * sizeof(double));
    double *hpred   = (double *)malloc(nnodes * sizeof(double));
    double *hnew    = (double *)malloc(nnodes * sizeof(double));

    if (!slope_x || !slope_y || !hpred || !hnew) {
        free(slope_x); free(slope_y); free(hpred); free(hnew);
        printf("FEFVSPM ERROR: FVM advection memory allocation failed\n");
        return 1;
    }

    /* ---- Step 1: limited slopes (MC) ---- */
    for (j = 0; j < ny; j++) {
        for (i = 0; i < nx; i++) {
            idx = i + j * nx;
            {
                double dl, dr;

                if (i > 0 && i < nx - 1) {
                    dl = (hc[idx]     - hc[idx - 1]) / dx;
                    dr = (hc[idx + 1] - hc[idx])     / dx;
                    slope_x[idx] = fvm_mc_limiter(dl, dr);
                } else if (i == 0) {
                    /* One-sided derivative at the left boundary. */
                    slope_x[idx] = (hc[idx + 1] - hc[idx]) / dx;
                } else {
                    /* One-sided derivative at the right boundary. */
                    slope_x[idx] = (hc[idx] - hc[idx - 1]) / dx;
                }

                if (j > 0 && j < ny - 1) {
                    dl = (hc[idx]      - hc[idx - nx]) / dy;
                    dr = (hc[idx + nx] - hc[idx])      / dy;
                    slope_y[idx] = fvm_mc_limiter(dl, dr);
                } else if (j == 0) {
                    /* One-sided derivative at the south boundary. */
                    slope_y[idx] = (hc[idx + nx] - hc[idx]) / dy;
                } else {
                    /* One-sided derivative at the north boundary. */
                    slope_y[idx] = (hc[idx] - hc[idx - nx]) / dy;
                }
            }
        }
    }

    /* ---- Step 2: Hancock half-step predictor (div u = 0) ---- */
    for (j = 0; j < ny; j++) {
        for (i = 0; i < nx; i++) {
            idx = i + j * nx;
            {
                double ux = s->u_h[2 * idx];
                double uy = s->u_h[2 * idx + 1];
                hpred[idx] = hc[idx]
                           - 0.5 * dt * (ux * slope_x[idx] + uy * slope_y[idx]);
            }
        }
    }

    /* ---- Step 3 & 4: face fluxes + conservative update ---- */
    for (j = 0; j < ny; j++) {
        for (i = 0; i < nx; i++) {
            idx = i + j * nx;
            {
                /* median-dual face lengths */
                double len_ew = (j == 0 || j == ny - 1) ? 0.5 * dy : dy;
                double len_ns = (i == 0 || i == nx - 1) ? 0.5 * dx : dx;

                /* median-dual volume */
                double vol;
                {
                    int is_i_b = (i == 0 || i == nx - 1);
                    int is_j_b = (j == 0 || j == ny - 1);
                    if      (is_i_b && is_j_b) vol = 0.25 * dx * dy;
                    else if (is_i_b || is_j_b) vol = 0.50 * dx * dy;
                    else                       vol = dx * dy;
                }

                double flux_sum = 0.0;

                /* -------- East face -------- */
                if (i < nx - 1) {
                    /* interior face: upwind between node i and node i+1 */
                    int eidx = idx + 1;
                    double uf = 0.5 * (s->u_h[2 * idx] + s->u_h[2 * eidx]);
                    double hL = hpred[idx]  + 0.5 * dx * slope_x[idx];
                    double hR = hpred[eidx] - 0.5 * dx * slope_x[eidx];
                    double hf = (uf > 0.0) ? hL : ((uf < 0.0) ? hR : 0.5 * (hL + hR));
                    flux_sum += uf * hf * len_ew;
                } else {
                    /* east boundary face is AT node i = nx-1: h_f = h* */
                    double uf = s->u_h[2 * idx];
                    double hf = hpred[idx];
                    flux_sum += uf * hf * len_ew;
                }

                /* -------- West face -------- */
                if (i > 0) {
                    /* interior face */
                    int widx = idx - 1;
                    double uf = 0.5 * (s->u_h[2 * idx] + s->u_h[2 * widx]);
                    double hL = hpred[widx] + 0.5 * dx * slope_x[widx];
                    double hR = hpred[idx]  - 0.5 * dx * slope_x[idx];
                    double hf = (uf > 0.0) ? hL : ((uf < 0.0) ? hR : 0.5 * (hL + hR));
                    flux_sum -= uf * hf * len_ew;
                } else {
                    /* west boundary face is AT node i = 0: h_f = h* */
                    double uf = s->u_h[2 * idx];
                    double hf = hpred[idx];
                    flux_sum -= uf * hf * len_ew;
                }

                /* -------- North face -------- */
                if (j < ny - 1) {
                    /* interior face */
                    int nidx = idx + nx;
                    double vf = 0.5 * (s->u_h[2 * idx + 1] + s->u_h[2 * nidx + 1]);
                    double hL = hpred[idx]  + 0.5 * dy * slope_y[idx];
                    double hR = hpred[nidx] - 0.5 * dy * slope_y[nidx];
                    double hf = (vf > 0.0) ? hL : ((vf < 0.0) ? hR : 0.5 * (hL + hR));
                    flux_sum += vf * hf * len_ns;
                } else {
                    /* north boundary face is AT node j = ny-1: h_f = h* */
                    double vf = s->u_h[2 * idx + 1];
                    double hf = hpred[idx];
                    flux_sum += vf * hf * len_ns;
                }

                /* -------- South face -------- */
                if (j > 0) {
                    /* interior face */
                    int sidx = idx - nx;
                    double vf = 0.5 * (s->u_h[2 * idx + 1] + s->u_h[2 * sidx + 1]);
                    double hL = hpred[sidx] + 0.5 * dy * slope_y[sidx];
                    double hR = hpred[idx]  - 0.5 * dy * slope_y[idx];
                    double hf = (vf > 0.0) ? hL : ((vf < 0.0) ? hR : 0.5 * (hL + hR));
                    flux_sum -= vf * hf * len_ns;
                } else {
                    /* south boundary face is AT node j = 0: h_f = h* */
                    double vf = s->u_h[2 * idx + 1];
                    double hf = hpred[idx];
                    flux_sum -= vf * hf * len_ns;
                }

                hnew[idx] = hc[idx] - dt / vol * flux_sum;
            }
        }
    }

    for (idx = 0; idx < nnodes; idx++) hc[idx] = hnew[idx];

    free(slope_x); free(slope_y); free(hpred); free(hnew);
    return(0);
}

/*
 * Strict 2-D CFL for the MUSCL FVM advection step:
 *
 *     dt <= cfl / ( max|ux|/dx + max|uy|/dy )
 *
 * cfl <= 0.8 recommended for the 2nd-order scheme.
 */
ErrorCode FEFVSPMGetStableTimestep_FVMAdvection(FEFVSPM s, double cfl, double *dt)
{
    double dt_min = 1.0e32;
    double dx = s->dx, dy = s->dy;
    int i, j, idx;

    for (j = 0; j < s->ny; j++) {
        for (i = 0; i < s->nx; i++) {
            idx = i + j * s->nx;
            {
                double ux = s->u_h[2 * idx];
                double uy = s->u_h[2 * idx + 1];
                double rate = fabs(ux) / dx + fabs(uy) / dy;
                if (rate > 1.0e-20) {
                    double d = cfl / rate;
                    if (d < dt_min) dt_min = d;
                }
            }
        }
    }
    *dt = dt_min;
    return(0);
}