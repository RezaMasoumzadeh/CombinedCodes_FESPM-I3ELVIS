/*
 * Stand-alone convergence test for the coupled surface advection-diffusion
 * equation using the existing FESLSPM Semi-Lagrangian (SL) advection and
 * P1-FEM diffusion routines.  No I3ELVIS code is called.
 *
 * PDE tested:
 *      h_t + u_x h_x + u_y h_y = kappa (h_xx + h_yy),
 * with constant velocity and constant diffusivity.
 *
 * The exact reference is the whole-space solution for a 2-D Gaussian.
 * The Gaussian is centered well inside [0,1]^2, so its tails at the
 * boundaries are very small over the selected final time.  FEM uses the
 * code's required homogeneous-Neumann boundary condition (NNNN).
 *
 * Time step:
 *      dt = 0.5 * min(dt_CFL, dt_FEM),
 * where FESLSPMComputeTimestep() calls the existing CFL and FEM spectral
 * stability estimators.  Since kappa and velocity are constant, this
 * timestep is computed once per mesh and remains valid for the run.
 *
 * Output:
 *      convergence_sl_fem.csv
 *      solution_N.csv for each resolution N (numerical and exact values).
 *
 * Compile from the source directory, for example:
 * gcc -O2 -Wall -fopenmp -o test_full_advdiff_sl_fem_order.exe \
 *   test_full_advdiff_sl_fem_order.c spmgrid.c spmsl.c spmupdate.c fespm.c \
 *   -lm
 *
 * If the linker reports unresolved BLAS symbols from other project objects,
 * add the BLAS library used by the project (e.g. -lopenblas).
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "spm.h"
#include "fespm.h"

#define PI 3.1415926535897932384626433832795

/* -------------------------- Test parameters -------------------------- */
static const double X0 = 0.0;
static const double X1 = 1.0;
static const double Y0 = 0.0;
static const double Y1 = 1.0;

static const double UX = 0.12;
static const double UY = -0.08;
static const double KAPPA = 2.0e-3;
static const double T_FINAL = 0.10;

static const double GAUSS_XC = 0.50;
static const double GAUSS_YC = 0.50;
static const double GAUSS_SIGMA = 0.10;

static const int RESOLUTIONS[] = {16, 32, 64, 128, 256};
static const int NRES = (int)(sizeof(RESOLUTIONS) / sizeof(RESOLUTIONS[0]));

static void check_error(ErrorCode ierr, const char *where)
{
    if (ierr != 0) {
        fprintf(stderr, "ERROR: %s failed (ErrorCode=%d)\n", where, ierr);
        exit(EXIT_FAILURE);
    }
}

static double exact_gaussian(double x, double y, double t)
{
    /* For h_t + u.grad(h) = kappa Laplacian(h), on R^2. */
    const double sigma2 = GAUSS_SIGMA * GAUSS_SIGMA;
    const double var = sigma2 + 2.0 * KAPPA * t;
    const double xc = GAUSS_XC + UX * t;
    const double yc = GAUSS_YC + UY * t;
    const double dx = x - xc;
    const double dy = y - yc;
    return (sigma2 / var) * exp(-(dx * dx + dy * dy) / (2.0 * var));
}

static void initialize_fields(FESLSPM spm)
{
    int i, j, id;
    double x, y;
    double *uv = (double *)malloc(2 * spm->nnodes * sizeof(double));
    double *vv = (double *)calloc(spm->nnodes, sizeof(double));

    if (!uv || !vv) {
        fprintf(stderr, "ERROR: velocity allocation failed\n");
        exit(EXIT_FAILURE);
    }

    for (j = 0; j < spm->ny; ++j) {
        y = Y0 + j * spm->dy;
        for (i = 0; i < spm->nx; ++i) {
            x = X0 + i * spm->dx;
            id = j * spm->nx + i;

            spm->h[id] = exp(-((x - GAUSS_XC) * (x - GAUSS_XC) +
                               (y - GAUSS_YC) * (y - GAUSS_YC)) /
                             (2.0 * GAUSS_SIGMA * GAUSS_SIGMA));

            uv[2 * id]     = UX;
            uv[2 * id + 1] = UY;
        }
    }

    check_error(FESLSPMSetInitialHeight(spm, spm->h), "SetInitialHeight");
    check_error(FESLSPMSetHorizontalVelocity(spm, uv), "SetHorizontalVelocity");
    check_error(FESLSPMSetVerticalVelocity(spm, vv), "SetVerticalVelocity");

    free(uv);
    free(vv);
}

static void compute_errors(FESLSPM spm, double *l2, double *linf)
{
    int i, j, id;
    double x, y, e, w, sum = 0.0;
    double maxe = 0.0;

    /* Composite trapezoidal weights for the nodal L2 integral. */
    for (j = 0; j < spm->ny; ++j) {
        y = Y0 + j * spm->dy;
        for (i = 0; i < spm->nx; ++i) {
            x = X0 + i * spm->dx;
            id = j * spm->nx + i;
            e = spm->h[id] - exact_gaussian(x, y, T_FINAL);

            w = spm->dx * spm->dy;
            if (i == 0 || i == spm->nx - 1) w *= 0.5;
            if (j == 0 || j == spm->ny - 1) w *= 0.5;

            sum += w * e * e;
            if (fabs(e) > maxe) maxe = fabs(e);
        }
    }

    *l2 = sqrt(sum);
    *linf = maxe;
}

static void write_solution(FESLSPM spm, int n)
{
    char filename[128];
    FILE *fp;
    int i, j, id;
    double x, y;

    snprintf(filename, sizeof(filename), "solution_%d.csv", n);
    fp = fopen(filename, "w");
    if (!fp) {
        fprintf(stderr, "WARNING: cannot write %s\n", filename);
        return;
    }

    fprintf(fp, "x,y,h_numerical,h_exact,error\n");
    for (j = 0; j < spm->ny; ++j) {
        y = Y0 + j * spm->dy;
        for (i = 0; i < spm->nx; ++i) {
            x = X0 + i * spm->dx;
            id = j * spm->nx + i;
            fprintf(fp, "%.16e,%.16e,%.16e,%.16e,%.16e\n",
                    x, y, spm->h[id], exact_gaussian(x, y, T_FINAL),
                    spm->h[id] - exact_gaussian(x, y, T_FINAL));
        }
    }
    fclose(fp);
}

static void run_one_resolution(int n, double *l2, double *linf, int *nsteps)
{
    FESLSPM spm = NULL;
    double dt, time = 0.0;
    int step = 0;

    check_error(FESLSPMCreate(&spm), "FESLSPMCreate");
    check_error(FESLSPMSetGeometry(spm, X0, X1, Y0, Y1), "SetGeometry");
    check_error(FESLSPMSetResolution(spm, n, n), "SetResolution");

    check_error(FESLSPMSetConstantDiffusivity(spm, KAPPA),
                "SetConstantDiffusivity");
    check_error(FESLSPMSetBoundaryConditions(spm, "NNNN"),
                "SetBoundaryConditions(NNNN)");
    check_error(FESLSPMSetSemiLagrangeInterpolationType(
                    spm, SLINTERPOLATION_UPWIND_CSPLINE_MONOTONE),
                "SetSemiLagrangeInterpolationType");

    initialize_fields(spm);
    memcpy(spm->h, spm->h_ic, (size_t)spm->nnodes * sizeof(double));

    /* Build the P1 triangular FEM mesh and assemble M and K. */
    check_error(FESPMCreate(spm, &spm->fespm), "FESPMCreate");

    /* Use the existing combined advection-CFL / explicit-FEM stability bound. */
    check_error(FESLSPMComputeTimestep(spm, spm->h, &dt),
                "FESLSPMComputeTimestep");
    dt *= 0.5; /* additional safety/accuracy factor */

    if (!(dt > 0.0) || !isfinite(dt)) {
        fprintf(stderr, "ERROR: invalid timestep %.16e for N=%d\n", dt, n);
        FESLSPMDestroy(&spm);
        exit(EXIT_FAILURE);
    }

    printf("\nN=%d: nodes=%d, triangles=%d, initial dt=%.6e\n",
           n, spm->nnodes, 2 * spm->ncells, dt);

    while (time < T_FINAL - 1.0e-14) {
        double dtn = dt;
        if (time + dtn > T_FINAL) dtn = T_FINAL - time;
        spm->dt = dtn;

        /* 1) Semi-Lagrangian advection: h^n -> h* */
        check_error(FESLSPMUpdate_SemiLagrangian(spm, dtn, spm->h),
                    "FESLSPMUpdate_SemiLagrangian");

        /* Preserve h* as the input field for the FEM diffusion stage. */
        memcpy(spm->h_c, spm->h, (size_t)spm->nnodes * sizeof(double));

        /* 2) Explicit-in-time P1 FEM diffusion: h* -> h^(n+1). */
        check_error(FESPMDiffusionStep(spm->fespm, spm, spm->h_c),
                    "FESPMDiffusionStep");

        time += dtn;
        ++step;

        if (step % 500 == 0) {
            printf("  step=%d, t=%.6f\n", step, time);
        }
    }

    compute_errors(spm, l2, linf);
    write_solution(spm, n);
    *nsteps = step;

    printf("N=%3d  steps=%5d  L2=%.8e  Linf=%.8e\n",
           n, step, *l2, *linf);

    FESLSPMDestroy(&spm); /* also destroys spm->fespm */
}

int main(void)
{
    FILE *fp;
    double l2_prev = 0.0, linf_prev = 0.0;
    double h_prev = 0.0;
    int r;

    fp = fopen("convergence_sl_fem.csv", "w");
    if (!fp) {
        fprintf(stderr, "ERROR: cannot create convergence_sl_fem.csv\n");
        return EXIT_FAILURE;
    }
    fprintf(fp, "N,dx,dt_steps,L2,Linf,order_L2,order_Linf\n");

    printf("============================================================\n");
    printf(" Stand-alone SL + P1 FEM advection-diffusion convergence\n");
    printf(" u=(%.4f, %.4f), kappa=%.4e, T=%.4f\n", UX, UY, KAPPA, T_FINAL);
    printf("============================================================\n");

    for (r = 0; r < NRES; ++r) {
        const int n = RESOLUTIONS[r];
        const double h = 1.0 / (double)(n - 1);
        double l2, linf;
        int nsteps;
        double p2 = 0.0, pinf = 0.0;

        run_one_resolution(n, &l2, &linf, &nsteps);

        if (r > 0) {
            p2 = log(l2_prev / l2) / log(h_prev / h);
            pinf = log(linf_prev / linf) / log(h_prev / h);
        }

        fprintf(fp, "%d,%.16e,%d,%.16e,%.16e,%.8f,%.8f\n",
                n, h, nsteps, l2, linf, p2, pinf);
        fflush(fp);

        printf("       spatial order: L2=%.4f, Linf=%.4f\n", p2, pinf);

        l2_prev = l2;
        linf_prev = linf;
        h_prev = h;
    }

    fclose(fp);

    printf("\nFinished. Results: convergence_sl_fem.csv\n");
    printf("Final fields: solution_16.csv ... solution_256.csv\n");
    return EXIT_SUCCESS;
}
